# Google Play کے لیے

1. Node.js انسٹال کریں۔
2. اس فولڈر میں `npm install` چلائیں۔
3. `npm run build` چلائیں۔
4. `npx cap add android`
5. `npx cap sync android`
6. `npx cap open android`
7. Android Studio میں Build > Generate Signed Bundle / APK > Android App Bundle منتخب کریں۔
8. Google Play Console میں Organization developer account اور Financial features declaration مکمل کریں۔

اہم: یہ موجودہ پیکیج ڈیمو ٹریڈنگ کے لیے ہے۔ حقیقی PSX/Forex/Crypto/Gold execution کے لیے لائسنس یافتہ broker/exchange/regulated partners، KYC/AML، payment/custody، privacy policy، terms اور متعلقہ قانونی منظوری درکار ہے۔ API keys ایپ میں شامل نہ کریں۔
