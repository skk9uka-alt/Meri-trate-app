import React,{useMemo,useState} from 'react';
import {createRoot} from 'react-dom/client';
import {LineChart,Line,XAxis,YAxis,Tooltip,ResponsiveContainer} from 'recharts';
import './style.css';

const markets={
 PSX:[['LUCK','Lucky Cement'],['OGDC','OGDCL'],['FFC','FFC'],['HUBC','Hub Power'],['MEBL','Meezan Bank']],
 Forex:[['EURUSD','EUR/USD'],['GBPUSD','GBP/USD'],['USDJPY','USD/JPY']],
 Crypto:[['BTC','Bitcoin'],['ETH','Ethereum'],['SOL','Solana']],
 Gold:[['XAUUSD','Gold / USD']]
};
const prices={LUCK:218.4,OGDC:248.1,FFC:382.7,HUBC:191.6,MEBL:456.2,EURUSD:1.1734,GBPUSD:1.3452,USDJPY:148.31,BTC:109240,ETH:3920,SOL:182.4,XAUUSD:3758.2};
const names=Object.fromEntries(Object.values(markets).flat());
function chart(base){return Array.from({length:18},(_,i)=>({i,p:base*(1+(Math.sin(i/2.5)*.008)+(i-9)*.0007)}))}
function App(){
 const [tab,setTab]=useState('PSX'), [selected,setSelected]=useState('LUCK'), [cash,setCash]=useState(1000000);
 const [qty,setQty]=useState(10),[orders,setOrders]=useState([]),[side,setSide]=useState('BUY'),[q,setQ]=useState('');
 const list=useMemo(()=>markets[tab].filter(x=>(x[0]+x[1]).toLowerCase().includes(q.toLowerCase())),[tab,q]);
 const price=prices[selected]||0;
 const trade=()=>{if(!qty||qty<=0)return;let total=price*qty;if(side==='BUY'&&total>cash){alert('ڈیمو بیلنس کافی نہیں');return}setCash(c=>side==='BUY'?c-total:c+total);setOrders(o=>[{time:new Date().toLocaleTimeString(),side,symbol:selected,qty,price,total},...o]);};
 return <div className="app" dir="rtl">
  <header><div><b>میری ٹریڈ</b><span> PSX • Forex • Crypto • Gold</span></div><div className="demo">ڈیمو اکاؤنٹ</div></header>
  <section className="hero"><h1>ایک جگہ، چار مارکیٹس</h1><p>حقیقی رقم لگانے سے پہلے ڈیمو میں خرید و فروخت آزمائیں۔</p><div className="cards"><div>ڈیمو بیلنس<h2>Rs {cash.toLocaleString(undefined,{maximumFractionDigits:2})}</h2></div><div>آج کے آرڈرز<h2>{orders.length}</h2></div><div>منتخب مارکیٹ<h2>{tab}</h2></div></div></section>
  <main><div className="panel"><nav>{Object.keys(markets).map(t=><button className={tab===t?'active':''} onClick={()=>{setTab(t);setSelected(markets[t][0][0])}}>{t}</button>)}</nav>
   <input placeholder="شیئر/اثاثہ تلاش کریں..." value={q} onChange={e=>setQ(e.target.value)}/>
   <div className="symbols">{list.map(([s,n])=><button className={selected===s?'sel':''} onClick={()=>setSelected(s)}><b>{s}</b><small>{n}</small><span>{prices[s].toLocaleString()}</span></button>)}</div>
  </div>
  <div className="panel"><div className="title"><h2>{names[selected]} <small>{selected}</small></h2><strong>{price.toLocaleString()}</strong></div>
   <div className="chart"><ResponsiveContainer width="100%" height={250}><LineChart data={chart(price)}><XAxis dataKey="i" hide/><YAxis domain={['auto','auto']} hide/><Tooltip/><Line type="monotone" dataKey="p" dot={false}/></LineChart></ResponsiveContainer></div>
   <div className="trade"><div className="sides"><button className={side==='BUY'?'buy':''} onClick={()=>setSide('BUY')}>خریدیں</button><button className={side==='SELL'?'sell':''} onClick={()=>setSide('SELL')}>فروخت</button></div>
   <label>مقدار<input type="number" min="1" value={qty} onChange={e=>setQty(Number(e.target.value))}/></label><p>کل: <b>{(price*qty).toLocaleString()}</b></p><button className="execute" onClick={trade}>ڈیمو آرڈر لگائیں</button></div>
  </div></main>
  <section className="panel orders"><h2>آرڈر ہسٹری</h2>{orders.length===0?<p>ابھی کوئی آرڈر نہیں۔</p>:<table><thead><tr><th>وقت</th><th>قسم</th><th>اثاثہ</th><th>مقدار</th><th>قیمت</th></tr></thead><tbody>{orders.map(o=><tr><td>{o.time}</td><td>{o.side}</td><td>{o.symbol}</td><td>{o.qty}</td><td>{o.price}</td></tr>)}</tbody></table>}</section>
  <footer>یہ ڈیمو ہے۔ لائیو PSX/Forex/Crypto/Gold ٹریڈنگ کے لیے متعلقہ لائسنس یافتہ بروکر، ایکسچینج/لیکویڈیٹی، KYC/AML، ادائیگی اور سکیورٹی انٹیگریشن ضروری ہیں۔</footer>
 </div>
}
createRoot(document.getElementById('root')).render(<App/>);