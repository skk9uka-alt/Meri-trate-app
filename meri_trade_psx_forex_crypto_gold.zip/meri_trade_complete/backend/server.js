import express from 'express'; import cors from 'cors';
const app=express(); app.use(cors()); app.use(express.json());
app.get('/api/health',(req,res)=>res.json({ok:true,app:'Meri Trade'}));
app.get('/api/markets',(req,res)=>res.json({PSX:['LUCK','OGDC','FFC','HUBC','MEBL'],Forex:['EURUSD','GBPUSD','USDJPY'],Crypto:['BTC','ETH','SOL'],Gold:['XAUUSD']}));
app.listen(4000,()=>console.log('Meri Trade API running on 4000'));