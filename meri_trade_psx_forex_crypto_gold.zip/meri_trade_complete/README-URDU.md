# میری ٹریڈ — PSX + Forex + Crypto + Gold

یہ فوری ڈیمو پروجیکٹ ہے۔ اس میں مارکیٹ ٹیبز، سرچ، چارٹ، ڈیمو Buy/Sell، بیلنس اور آرڈر ہسٹری شامل ہیں۔

## چلانے کا طریقہ
1. Node.js انسٹال کریں۔
2. `frontend` فولڈر میں `npm install` پھر `npm run dev`
3. `backend` فولڈر میں `npm install` پھر `npm start`
4. اصل رقم والی ٹریڈنگ ابھی شامل نہیں ہے۔

## لائیو بنانے کے لیے
PSX کے لیے SECP لائسنس یافتہ securities broker/API یا مجاز شراکت دار درکار ہوگا۔ Forex/Crypto/Gold کے لیے بھی متعلقہ مجاز execution, custody, payment, KYC/AML اور market-data providers درکار ہوں گے۔ API keys کو ایپ میں ہارڈ کوڈ نہ کریں۔
